public enum TipoEspetaculo {
    EM_SALA,
    AR_LVIRE,
    OUTRO
}
