public class Main {
    public static void main(String[] args) {
        Peixe p = new Peixe("Sardinha", 321);
    }
}